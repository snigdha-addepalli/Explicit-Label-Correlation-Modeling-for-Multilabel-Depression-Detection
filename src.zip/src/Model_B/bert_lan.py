
# IMPORTS
import os
import torch
import json
import numpy as np
import pandas as pd
import random
from torch import nn
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertModel, get_linear_schedule_with_warmup
from torch.optim import AdamW
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, precision_score, recall_score, classification_report, hamming_loss
import torch.nn.functional as F
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix

random.seed(42)
np.random.seed(42)
torch.manual_seed(42)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}\n")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")

os.makedirs(OUTPUT_DIR, exist_ok=True)

# HYPERPARAMETERS

BATCH_SIZE = 32
MAX_LEN = 256
NUM_EPOCHS = 8
BERT_HIDDEN_SIZE = 768
LABEL_EMBEDDING_DIM = 256
MODEL_SAVE_PATH = os.path.join(OUTPUT_DIR, "best_synthetic_model.pth")
BEST_VAL_F1 = -1.0

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

# FOCAL LOSS

class BCEFocalLoss(nn.Module):
    def __init__(self, pos_weight=None, gamma=2.0):
        super().__init__()
        self.gamma = gamma
        self.pos_weight = pos_weight

    def forward(self, logits, targets):
        bce_loss = F.binary_cross_entropy_with_logits(
            logits, targets,
            reduction='none',
            pos_weight=self.pos_weight
        )

        probs = torch.sigmoid(logits)
        p_t = probs * targets + (1 - probs) * (1 - targets)
        focal_weight = (1 - p_t) ** self.gamma

        return (focal_weight * bce_loss).mean()


# MODEL - BERT_LAN LAYER

class BERT_LAN_Classifier(nn.Module):
    def __init__(self, num_labels, bert_hidden_size=768, label_embedding_dim=256):
        super().__init__()
        self.num_labels = num_labels

        self.bert = BertModel.from_pretrained('bert-base-uncased')
        for param in self.bert.parameters():
            param.requires_grad = False
        for param in self.bert.encoder.layer[-1].parameters():
            param.requires_grad = True

        self.label_embeddings = nn.Embedding(num_labels, label_embedding_dim)
        self.attention_projection = nn.Linear(bert_hidden_size, label_embedding_dim)

        self.classifier = nn.Sequential(
            nn.Linear(bert_hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 1)
        )

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids
        )
        H = outputs.last_hidden_state
        H_proj = self.attention_projection(H)

        logits = []
        for l in range(self.num_labels):
            e_l = self.label_embeddings.weight[l]
            scores = torch.matmul(H_proj, e_l)
            scores = scores.masked_fill(attention_mask == 0, -1e9)
            alpha = torch.softmax(scores, dim=1)
            z_l = torch.sum(H * alpha.unsqueeze(-1), dim=1)
            logit = self.classifier(z_l)
            logits.append(logit)

        return torch.cat(logits, dim=1)

# DATASET

class RedditDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, mlb):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.mlb = mlb

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        labels = self.labels[idx]

        encoding = self.tokenizer(
            text,
            truncation=True,
            padding='max_length',
            max_length=MAX_LEN,
            return_tensors='pt'
        )

        labels_binary = self.mlb.transform([labels])

        return {
            'input_ids': encoding['input_ids'].squeeze(),
            'attention_mask': encoding['attention_mask'].squeeze(),
            'labels': torch.tensor(labels_binary, dtype=torch.float32).squeeze()
        }

# LOAD DATA

print("Loading data from combined.json...")
all_entries = []
COMBINED_FILE = "combined.json"

with open(COMBINED_FILE, "r") as f:
    for line in f:
        if line.strip():
            entry = json.loads(line)
            if 'text' in entry and 'emotions' in entry:
                all_entries.append(entry)

all_texts = [entry['text'] for entry in all_entries]
all_labels = [entry['emotions'] for entry in all_entries]

X_train, X_temp, y_train, y_temp = train_test_split(
    all_texts, all_labels, test_size=0.2, random_state=42, shuffle=True
)
X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.5, random_state=42, shuffle=True
)

train_texts, train_labels = X_train, y_train
val_texts, val_labels = X_val, y_val
test_texts, test_labels = X_test, y_test

print(f"Original split: Train={len(train_texts)}, Val={len(val_texts)}, Test={len(test_texts)}\n")

# LABEL PROCESSING

mlb = MultiLabelBinarizer()
mlb.fit(train_labels)
num_labels = len(mlb.classes_)
label_names = mlb.classes_

print(f" Labels: {list(label_names)}\n")

# SYNTHETIC NEGATIVE SAMPLING

print("Creating synthetic negative examples...")

def create_synthetic_negatives(texts, labels, augmentation_factor=2):
    """
    Create synthetic examples with fewer labels to teach discrimination

    For each multi-label example, create versions with subsets of labels
    This teaches: "Same text can have DIFFERENT valid label combinations"
    """
    aug_texts = []
    aug_labels = []

    for text, label_list in zip(texts, labels):
        # Always keep original
        aug_texts.append(text)
        aug_labels.append(label_list)

        # If multi-label, create synthetic versions with fewer labels
        if len(label_list) > 2:
            for _ in range(augmentation_factor):
                # Keep 1-2 labels randomly (forces discrimination)
                num_keep = random.randint(1, min(2, len(label_list)))
                kept_labels = random.sample(label_list, num_keep)

                aug_texts.append(text)
                aug_labels.append(kept_labels)

        elif len(label_list) == 2:
            # For 2-label examples, sometimes keep just 1
            if random.random() < 0.5:
                kept_label = random.choice(label_list)
                aug_texts.append(text)
                aug_labels.append([kept_label])

    return aug_texts, aug_labels

# Generate synthetic examples
train_texts_aug, train_labels_aug = create_synthetic_negatives(
    train_texts,
    train_labels,
    augmentation_factor=2
)

print(f"  Original training: {len(train_texts)} examples")
print(f"  After augmentation: {len(train_texts_aug)} examples")

# Analyze distribution
label_counts = [len(labels) for labels in train_labels_aug]
print(f"\nLabel count distribution:")
print(f"  1 label:   {sum(1 for c in label_counts if c == 1)} examples")
print(f"  2 labels:  {sum(1 for c in label_counts if c == 2)} examples")
print(f"  3-5 labels: {sum(1 for c in label_counts if 3 <= c <= 5)} examples")
print(f"  6+ labels:  {sum(1 for c in label_counts if c >= 6)} examples\n")

# Use augmented data
train_texts = train_texts_aug
train_labels = train_labels_aug

# CLASS WEIGHTS

print("Calculating class weights...")
train_labels_binary = mlb.transform(train_labels)
num_positives = np.sum(train_labels_binary, axis=0)
num_total = len(train_labels_binary)
num_negatives = num_total - num_positives
pos_weights = num_negatives / (num_positives + 1e-6)
pos_weights = np.clip(pos_weights, 1.0, 10.0)
pos_weights_tensor = torch.tensor(pos_weights, dtype=torch.float).to(device)

# CURRICULUM SETUP

print("\n Setting up curriculum learning...")

def split_by_label_count(texts, labels):
    data_1_2 = []
    data_3_5 = []
    data_6_plus = []

    for text, label in zip(texts, labels):
        n = len(label)
        if n <= 2:
            data_1_2.append((text, label))
        elif n <= 5:
            data_3_5.append((text, label))
        else:
            data_6_plus.append((text, label))

    return data_1_2, data_3_5, data_6_plus

data_1_2, data_3_5, data_6_plus = split_by_label_count(train_texts, train_labels)

print(f"  1-2 labels: {len(data_1_2)} examples")
print(f"  3-5 labels: {len(data_3_5)} examples")
print(f"  6+ labels:  {len(data_6_plus)} examples\n")

# VALIDATION SETUP

validation_dataset = RedditDataset(val_texts, val_labels, tokenizer, mlb)
validation_loader = DataLoader(validation_dataset, batch_size=BATCH_SIZE, shuffle=False)
threshold_range = np.arange(0.05, 0.96, 0.01)

def evaluate_validation(model, validation_loader, device, num_labels, mlb, threshold_range):
    model.eval()
    all_val_probabilities = []
    all_val_true_labels = []

    with torch.no_grad():
        for batch in validation_loader:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)

            logits = model(input_ids=input_ids, attention_mask=attention_mask)
            probabilities = torch.sigmoid(logits)

            all_val_probabilities.append(probabilities.cpu().numpy())
            all_val_true_labels.append(labels.cpu().numpy())

    all_probs = np.concatenate(all_val_probabilities, axis=0)
    all_true = np.concatenate(all_val_true_labels, axis=0)

    optimal_thresholds = np.zeros(num_labels)

    for i in range(num_labels):
        best_label_f1 = -1.0
        best_label_threshold = 0.5
        true_label = all_true[:, i]
        prob_label = all_probs[:, i]

        for t in threshold_range:
            t = round(t, 2)
            preds_label = (prob_label > t).astype(int)
            f1 = f1_score(true_label, preds_label, average='binary', zero_division=0)

            if f1 > best_label_f1:
                best_label_f1 = f1
                best_label_threshold = t

        optimal_thresholds[i] = best_label_threshold

    thresholds_reshaped = optimal_thresholds.reshape(1, -1)
    final_predictions = (all_probs > thresholds_reshaped).astype(int)
    micro_f1 = f1_score(all_true, final_predictions, average='micro', zero_division=0)

    return micro_f1, optimal_thresholds, all_probs, all_true


# MODEL INITIALIZATION

print("Initializing model...")
model = BERT_LAN_Classifier(
    num_labels=num_labels,
    bert_hidden_size=BERT_HIDDEN_SIZE,
    label_embedding_dim=LABEL_EMBEDDING_DIM
).to(device)

# OPTIMIZER & LOSS

optimizer = AdamW(model.parameters(), lr=2e-5, weight_decay=0.05)
loss_fn = BCEFocalLoss(pos_weight=pos_weights_tensor, gamma=2.0)

print("✅ Model ready!\n")


# CONTRASTIVE LOSS WITH NEGATIVE PENALTY

def contrastive_focal_loss(logits, labels, negative_weight=0.5):
    """
    Focal loss + strong penalty for false positives
    Forces model to be selective
    """
    # Focal loss
    probs = torch.sigmoid(logits)
    bce = F.binary_cross_entropy_with_logits(
        logits, labels, pos_weight=pos_weights_tensor, reduction='none'
    )
    p_t = probs * labels + (1 - probs) * (1 - labels)
    focal = ((1 - p_t) ** 2.0) * bce

    # Strong penalty for predicting labels that aren't present
    negative_mask = (labels == 0).float()
    neg_penalty = torch.mean(probs * negative_mask) * negative_weight

    return focal.mean() + neg_penalty


# CURRICULUM TRAINING LOOP


print("STARTING CURRICULUM TRAINING WITH SYNTHETIC NEGATIVES")

val_f1_history = []
train_loss_history = []

for epoch in range(NUM_EPOCHS):

    # ===== CURRICULUM STAGES =====
    if epoch < 3:
        stage_name = "STAGE 1: Simple (1-2 labels)"
        current_data = data_1_2
        negative_weight = 0.8  # Strong penalty in early stages
    elif epoch < 6:
        stage_name = "STAGE 2: Medium (1-5 labels)"
        current_data = data_1_2 + data_3_5
        negative_weight = 0.5
    else:
        stage_name = "STAGE 3: Full dataset"
        current_data = data_1_2 + data_3_5 + data_6_plus
        negative_weight = 0.3  # Lower penalty for complex cases


    print(f"EPOCH {epoch + 1}/{NUM_EPOCHS} - {stage_name}")
    print(f"Training on {len(current_data)} examples")

    # ===== CREATE LOADER =====
    current_texts = [item[0] for item in current_data]
    current_labels = [item[1] for item in current_data]

    current_dataset = RedditDataset(current_texts, current_labels, tokenizer, mlb)
    current_loader = DataLoader(current_dataset, batch_size=BATCH_SIZE, shuffle=True)

    # Scheduler for this epoch
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(0.1 * len(current_loader)),
        num_training_steps=len(current_loader)
    )

    # ===== TRAINING =====
    model.train()
    total_epoch_loss = 0.0

    for i, batch in enumerate(current_loader):
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['labels'].to(device)

        optimizer.zero_grad()
        logits = model(input_ids=input_ids, attention_mask=attention_mask)

        # Use contrastive loss with stage-specific negative weight
        loss = contrastive_focal_loss(logits, labels, negative_weight=negative_weight)

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        scheduler.step()

        total_epoch_loss += loss.item()

        if (i + 1) % 50 == 0:
            print(f"  Batch {i + 1}/{len(current_loader)}, Loss: {loss.item():.4f}")

    # ===== VALIDATION =====
    avg_loss = total_epoch_loss / len(current_loader)
    train_loss_history.append(avg_loss)

    print(f"\n--- Epoch {epoch + 1} Summary ---")
    print(f"  Training Loss: {avg_loss:.4f}")

    current_val_f1, _, _, _ = evaluate_validation(
        model, validation_loader, device, num_labels, mlb, threshold_range
    )

    val_f1_history.append(current_val_f1)
    print(f"  Validation F1: {current_val_f1:.4f}")

    if current_val_f1 > BEST_VAL_F1:
        BEST_VAL_F1 = current_val_f1
        print(f" NEW BEST MODEL! F1: {BEST_VAL_F1:.4f}")
        torch.save(model.state_dict(), MODEL_SAVE_PATH)
    else:
        print(f"  (Best: {BEST_VAL_F1:.4f})")



# TRAINING COMPLETE

print(f" TRAINING COMPLETE!")
print(f"   Best Validation F1: {BEST_VAL_F1:.4f}")
print(f"   Model saved: {MODEL_SAVE_PATH}")


print("\n TRAINING HISTORY:")
for i, (val_f1, loss) in enumerate(zip(val_f1_history, train_loss_history), 1):
    stage = "Stage 1" if i <= 3 else "Stage 2" if i <= 6 else "Stage 3"
    print(f"Epoch {i:2d} ({stage}) | Val F1: {val_f1:.4f} | Loss: {loss:.4f}")


# LOAD BEST MODEL & COMPUTE THRESHOLDS

print(f"\n Loading best model from {MODEL_SAVE_PATH}...")
model.load_state_dict(torch.load(MODEL_SAVE_PATH))
model.to(device)

final_val_f1, optimal_thresholds, _, _ = evaluate_validation(
    model, validation_loader, device, num_labels, mlb, threshold_range
)

print("\n OPTIMAL THRESHOLDS:")
for label, threshold in zip(label_names, optimal_thresholds):
    print(f"  {label:<30} {threshold:.2f}")

# Save thresholds
np.save('optimal_thresholds_synthetic.npy', optimal_thresholds)
threshold_dict = {label: float(thresh) for label, thresh in zip(label_names, optimal_thresholds)}
with open('optimal_thresholds_synthetic.json', 'w') as f:
    json.dump(threshold_dict, f, indent=2)

print("\n Thresholds saved!")


# TEST SET EVALUATION


# Create test loader
test_dataset = RedditDataset(test_texts, test_labels, tokenizer, mlb)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

print(f"\n Evaluating on {len(test_texts)} test examples...")

model.eval()
all_predictions_initial = []
all_true_labels = []
all_probabilities = []

with torch.no_grad():
    for batch in test_loader:
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['labels'].to(device)

        logits = model(input_ids=input_ids, attention_mask=attention_mask)
        probabilities = torch.sigmoid(logits)

        all_probabilities.append(probabilities.cpu().numpy())
        all_true_labels.append(labels.cpu().numpy())

all_probabilities = np.concatenate(all_probabilities, axis=0)
all_true_labels = np.concatenate(all_true_labels, axis=0)

print(" Probabilities computed for all test examples\n")


# find optimal thresholds

print(" Finding F1-optimal thresholds for each label...")

threshold_options = np.arange(0.30, 0.70, 0.05)  # Test: 0.30, 0.35, 0.40, ..., 0.65
optimal_thresholds_f1 = np.zeros(num_labels)

for i in range(num_labels):
    best_label_f1 = 0
    best_label_threshold = 0.5

    true_label = all_true_labels[:, i]
    prob_label = all_probabilities[:, i]

    # Try each threshold value
    for thresh in threshold_options:
        preds = (prob_label > thresh).astype(int)
        label_f1 = f1_score(true_label, preds, average='binary', zero_division=0)

        if label_f1 > best_label_f1:
            best_label_f1 = label_f1
            best_label_threshold = thresh

    optimal_thresholds_f1[i] = best_label_threshold
    print(f"  {label_names[i]:<30} Threshold: {best_label_threshold:.2f}, F1: {best_label_f1:.4f}")


# appling optimal threshold

print("\nApplying F1-optimal thresholds to test set...")

final_predictions = (all_probabilities > optimal_thresholds_f1).astype(int)

# Calculate final metrics
final_precision = precision_score(all_true_labels, final_predictions, average='micro', zero_division=0)
final_recall = recall_score(all_true_labels, final_predictions, average='micro', zero_division=0)
final_f1 = f1_score(all_true_labels, final_predictions, average='micro', zero_division=0)
final_hamming = hamming_loss(all_true_labels, final_predictions)


print(" FINAL TEST SET RESULTS")

print(f"  Precision:     {final_precision:.4f}")
print(f"  Recall:        {final_recall:.4f}")
print(f"  F1-Score:      {final_f1:.4f}")
print(f"  Hamming Loss:  {final_hamming:.4f}")
print("=" * 80)

print("\n💾 Saving results and thresholds...")

# Save thresholds
F1_OPTIMIZED_THRESHOLDS = {
    label: float(thresh) for label, thresh in zip(label_names, optimal_thresholds_f1)
}

np.save(os.path.join(OUTPUT_DIR, "f1_optimized_thresholds.npy"), optimal_thresholds_f1)

with open('f1_optimized_thresholds.json', 'w') as f:
    json.dump(F1_OPTIMIZED_THRESHOLDS, f, indent=2)

# Save complete results
final_results = {
    'model_type': 'BERT_LAN_synthetic_negatives_curriculum',
    'test_precision': float(final_precision),
    'test_recall': float(final_recall),
    'test_f1': float(final_f1),
    'test_hamming_loss': float(final_hamming),
    'f1_optimized_thresholds': F1_OPTIMIZED_THRESHOLDS,
    'validation_f1': float(BEST_VAL_F1),
    'num_test_samples': len(test_texts),
    'per_label_f1': {
        label: float(f1_score(all_true_labels[:, i], final_predictions[:, i], average='binary', zero_division=0))
        for i, label in enumerate(label_names)
    }
}

with open(os.path.join(OUTPUT_DIR, "final_submission_results.json"), "w") as f:
    json.dump(final_results, f, indent=2)

print("FINAL SUMMARY")


print(f"\n F1 SCORE: {final_f1:.4f}")
print(f"\n Complete Metrics:")
print(f"  • Precision:     {final_precision:.4f}")
print(f"  • Recall:        {final_recall:.4f}")
print(f"  • F1-Score:      {final_f1:.4f}")
print(f"  • Hamming Loss:  {final_hamming:.4f}")

print(f"\n🎯 Model Architecture:")
print(f"  • BERT + Label Attention Network")
print(f"  • Synthetic negative sampling")
print(f"  • Curriculum learning (3 stages)")
print(f"  • F1-optimized thresholds")

# CONFUSION MATRICES FOR EACH EMOTION LABEL

# 1.  Individual Confusion Matrix per Label

# Create figure with subplots (2 rows x 4 columns for 8 emotions)
fig, axes = plt.subplots(2, 4, figsize=(20, 10))
axes = axes.flatten()

for i, label_name in enumerate(label_names):
    # Get true and predicted for this label
    y_true = all_true_labels[:, i]
    y_pred = final_predictions[:, i]

    # Compute confusion matrix
    cm = confusion_matrix(y_true, y_pred)

    # Plot
    ax = axes[i]
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=['Pred 0', 'Pred 1'],
                yticklabels=['True 0', 'True 1'],
                ax=ax, cbar=True)

    ax.set_title(f'Confusion Matrix: {label_name}', fontsize=12, fontweight='bold')
    ax.set_ylabel('True', fontsize=10)
    ax.set_xlabel('Predicted', fontsize=10)

plt.tight_layout()
plt.show()

#  2: Label Correlation Heatmaps 

# Calculate correlation matrices
# 1. True label correlations
true_labels_df = pd.DataFrame(all_true_labels, columns=label_names)
true_correlation = true_labels_df.corr()

# 2. Predicted label correlations
pred_labels_df = pd.DataFrame(final_predictions, columns=label_names)
pred_correlation = pred_labels_df.corr()

# 3. Difference matrix
diff_correlation = pred_correlation - true_correlation

# Create figure with 3 subplots
fig, axes = plt.subplots(1, 3, figsize=(24, 7))

# Plot 1: True correlations
sns.heatmap(true_correlation, annot=True, fmt='.2f', cmap='Blues',
            square=True, ax=axes[0], vmin=-1, vmax=1,
            cbar_kws={'label': 'Correlation'})
axes[0].set_title('True Label Correlations (Test Set)', fontsize=14, fontweight='bold')
axes[0].set_xticklabels(axes[0].get_xticklabels(), rotation=45, ha='right')
axes[0].set_yticklabels(axes[0].get_yticklabels(), rotation=0)

# Plot 2: Model-predicted correlations
sns.heatmap(pred_correlation, annot=True, fmt='.2f', cmap='Blues',
            square=True, ax=axes[1], vmin=-1, vmax=1,
            cbar_kws={'label': 'Correlation'})
axes[1].set_title('Model-Predicted Correlations (Test Predictions)', fontsize=14, fontweight='bold')
axes[1].set_xticklabels(axes[1].get_xticklabels(), rotation=45, ha='right')
axes[1].set_yticklabels(axes[1].get_yticklabels(), rotation=0)

# Plot 3: Difference (Predicted - True)
sns.heatmap(diff_correlation, annot=True, fmt='.2f', cmap='RdBu_r',
            square=True, ax=axes[2], center=0, vmin=-0.3, vmax=0.3,
            cbar_kws={'label': 'Difference'})
axes[2].set_title('Difference (Predicted − True)', fontsize=14, fontweight='bold')
axes[2].set_xticklabels(axes[2].get_xticklabels(), rotation=45, ha='right')
axes[2].set_yticklabels(axes[2].get_yticklabels(), rotation=0)

plt.tight_layout()
plt.show()

# PRINT CONFUSION MATRIX SUMMARY

print("\n CONFUSION MATRIX SUMMARY:")
print(f"{'Label':<30} {'TP':<8} {'TN':<8} {'FP':<8} {'FN':<8} {'Precision':<12} {'Recall':<12}")


for i, label_name in enumerate(label_names):
    y_true = all_true_labels[:, i]
    y_pred = final_predictions[:, i]

    cm = confusion_matrix(y_true, y_pred)

    # Extract values
    tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)

    # Calculate metrics
    prec = tp / (tp + fp) if (tp + fp) > 0 else 0
    rec = tp / (tp + fn) if (tp + fn) > 0 else 0

    print(f"{label_name:<30} {tp:<8} {tn:<8} {fp:<8} {fn:<8} {prec:<12.2%} {rec:<12.2%}")

