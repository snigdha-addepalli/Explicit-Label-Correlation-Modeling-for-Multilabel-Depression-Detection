import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import json, random
import torch, numpy as np
from torch.utils.data import random_split
import re

def basic_tokenizer(text):
    text = text.lower()
    tokens = re.findall(r"[a-zA-Z]+", text)
    return tokens

print("check-1")
LABELS = [
    'anger',
    'brain dysfunction (forget)',
    'emptiness',
    'hopelessness',
    'loneliness',
    'sadness',
    'suicide intent',
    'worthlessness'
]
NUM_LABELS = len(LABELS)

EMBEDDING_DIM = 300
HIDDEN_DIM = 256
NUM_LAYERS = 1
NUM_LABELS = len(LABELS)
EPOCHS = 200
LR = 1e-4
BATCH_SIZE = 8
freeze_embeddings = False
dropout = 0.2
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

tokenizer = basic_tokenizer

from collections import Counter
counter = Counter()
dataset_raw = []
with open("combined.json") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        dataset_raw.append(json.loads(line))

for d in dataset_raw:
    counter.update(tokenizer(d["post"]))
    
word2idx = {"<pad>": 0, "<unk>": 1}
for word in counter:
    word2idx[word] = len(word2idx)

def load_glove_txt(path, dim=300):
    vocab, vectors = {}, []
    with open(path, encoding="utf8") as f:
        for line in f:
            parts = line.rstrip().split(" ")
            word, nums = parts[0], parts[1:]
            if len(nums) != dim:
                continue
            vocab[word] = len(vectors)
            vectors.append(np.asarray(nums, dtype=np.float32))
    print(f"Loaded {len(vocab):,} words from {path}")
    return vocab, torch.tensor(np.stack(vectors), dtype=torch.float32)

vocab, glove_vectors = load_glove_txt("glove/glove.6B.300d.txt")

embedding_matrix = torch.randn(len(word2idx), 300)

for word, idx in word2idx.items():
    if word in vocab:
        embedding_matrix[idx] = glove_vectors[vocab[word]]

embedding_matrix[word2idx["<pad>"]] = torch.zeros(300)
embedding_matrix[word2idx["<unk>"]] = torch.randn(300) * 0.1

class EmotionDataset(Dataset):
    def __init__(self, path):
        self.data = []
        with open(path) as f:
            for line in f:
                if not line.strip():
                    continue
                d = json.loads(line)
                self.data.append(d)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        d = self.data[idx]
        text = d["post"]
        labels = d["emotions"]  
        
        tokens = tokenizer(text)
        ids = [word2idx.get(t, word2idx["<unk>"]) for t in tokens]
    
        max_len = 256
        if len(ids) < max_len:
            ids = ids + [word2idx["<pad>"]] * (max_len - len(ids))
        else:
            ids = ids[:max_len]
    
        y = torch.zeros(NUM_LABELS)
        for lbl in labels:
            if lbl in LABELS:
                y[LABELS.index(lbl)] = 1.0
    
        return torch.tensor(ids, dtype=torch.long), y


class LSTM_Implicit(nn.Module):
    def __init__(self, vocab_dim, embedding_dim, hidden_dim, num_labels, embedding_matrix=None, freeze_embeddings=True):
        super().__init__()

        self.embedding = nn.Embedding(vocab_dim, embedding_dim)
        if embedding_matrix is not None:
            self.embedding.weight.data.copy_(embedding_matrix.to(self.embedding.weight.device))

            self.embedding.weight.requires_grad = not freeze_embeddings

        self.bilstm = nn.LSTM(
            embedding_dim, hidden_dim, bidirectional=True, batch_first=True
        )

        self.layernorm = nn.LayerNorm(hidden_dim * 2)
        self.dropout = nn.Dropout(0.2)
        self.fc = nn.Linear(hidden_dim * 2, num_labels)

    def forward(self, input_ids):
        x = self.embedding(input_ids)
        H, _ = self.bilstm(x)
        H = self.layernorm(H)
        H = self.dropout(H)

        pad = torch.tensor(word2idx["<pad>"], device=input_ids.device)
        mask = (input_ids != pad).unsqueeze(-1)

        H_masked = H * mask
        seq_repr = H_masked.sum(dim=1) / mask.sum(dim=1).clamp(min=1)
        logits = self.fc(seq_repr)  

        return logits

def train_model(model, train_loader, optimizer, criterion, epochs):
    model.train()
    for epoch in range(epochs):
        total_loss = 0.0
        for batch in train_loader:
            input_ids, labels = [b.to(DEVICE) for b in batch]
            optimizer.zero_grad()
            logits = model(input_ids)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f"Epoch {epoch+1}/{epochs} | Loss: {total_loss/len(train_loader):.4f}")

if __name__ == "__main__":
    dataset = EmotionDataset("combined.json")   

    train_size = int(0.8 * len(dataset))
    test_size = len(dataset) - train_size

    train_dataset, test_dataset = random_split(dataset, [train_size, test_size])
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=True)

    model = LSTM_Implicit(
    vocab_dim=len(word2idx),
    embedding_dim=EMBEDDING_DIM,
    hidden_dim=HIDDEN_DIM,
    num_labels=NUM_LABELS,
    embedding_matrix=embedding_matrix,
    freeze_embeddings=False
    ).to(DEVICE)

    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    criterion = nn.BCEWithLogitsLoss()

    train_model(model, train_loader, optimizer, criterion, EPOCHS)


SAVE_PATH = "lstm_implicit_model.pt"

torch.save(model.state_dict(), SAVE_PATH)
print(f"Model weights saved to {SAVE_PATH}")

with open("word2idx.json", "w") as f:
    json.dump(word2idx, f)

torch.save(embedding_matrix, "embedding_matrix.pt")

config = {
    "labels": LABELS,
    "embedding_dim": EMBEDDING_DIM,
    "hidden_dim": HIDDEN_DIM,
    "num_labels": NUM_LABELS,
    "tokenizer_name": "basic_tokenizer",
    "vocab_size": len(word2idx)

}

import json
with open("model_config_implicit.json", "w") as f:
    json.dump(config, f, indent=4)
print("Model configuration saved to model_config.json")